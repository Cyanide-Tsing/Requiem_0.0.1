const itemList = {
    'minecraft:sponge':'aqua',
    'quark:bottled_cloud':'cloud',
    'minecraft:amethyst_cluster':'thrice',
    'minecraft:redstone':'link',
    'minecraft:arrow':'step',
    'createaddition:modular_accumulator':'fulmen',
    'irons_spellbooks:bottle_o_lightning':'fulmen',
    'irons_spellbooks:divine_pearl':'divinity',
    'minecraft:echo_shard':'eldritch',
    'goety:grimoire_of_goodwill':'ally',
    'quark:abascus':'distance',
    'minecraft:crossbow':'crosshair',
    'quark:redstone_randomizer':'random',
    'minecraft:ender_pearl':'termination'
}

const entityList = {
    'minecraft:zombie':['end'],
    'minecraft:vex':['new','fabrication'],
    'minecraft:allay':['new','fabrication','ally'],
    'minecraft:skeleton':['break','if','range','target'],
    'minecraft:creeper':['contact','sense', 'dessociate', 'erupt'],
    'minecraft:enderman':['termination','void', 'dessociate'],
    'minecraft:stray':['recoil'],
    'minecraft:villager':['interpret'],
    'minecraft:iron_golem':['burdened'],
    'minecraft:evoker':['fabrication','new'],
    'minecraft:silverfish':['sense'],
    'minecraft:ravager':['burdened'],
    'minecraft:endermite':['void'],
    'minecraft:warden':['eldritch'],
    'minecraft:blaze':['pyre'],
    'minecraft:wither':['wither'],
    'irons_spellbooks:pyromancer':['evoke','pyre'],
    'irons_spellbooks:cryomancer':['evoke'],
    'irons_spellbooks:archevoker':['evoke','fabrication'],
    'irons_spellbooks:apothecarist':['evoke','verdure'],
    'irons_spellbooks:cultist':['evoke','sanguine'],
    'irons_spellbooks:priest':['interpret'],
    'traveloptics:aquamancer':['evoke','aqua'],
    'traveloptics:aquamaster':['evoke','aqua'],
    'mowziesmob:bluff':['terra', 'erupt'],
    'twilightforest:naga':['loop'],
    'twilightforest:lich':['enemy'],
    'twilightforest:minoshroom':['insect','thrice'],
    'twilightforest:hydra':['pyre'],
    'twilightforest:snow_queen':['glacier'],
    'twilightforest:phantom_knight':['thrice'],
    'twilightforest:ur_ghast':['pyre','levitated'],
    'twilightforest:alpha_yeti':['toward']
}

EntityEvents.death(event=>{
    if(!event.source.player)return;
    if(event.source.player.offHandItem.id !== 'kubejs:writable_wordcard' || event.source.player.offHandItem.damageValue === 0)return;
    if(event.entity.type === "minecraft:player") event.entity.block.popItem(Item.of("kubejs:wordcard", 1, {Word:"self"}))
    if(entityList[event.entity.type] && Math.random()<0.8){
        if(event.entity.getMainHandItem() !== 'minecraft:air' && Math.random<0.5) event.entity.block.popItem(Item.of('kubejs:wordcard', 1, {Word:"grant"}))
        else event.entity.block.popItem(Item.of('kubejs:wordcard', 1, {Word:entityList[event.entity.type][Math.floor(entityList[event.entity.type].length*Math.random())]}));
        if(!event.source.player.isCreative())event.player.offHandItem.damageValue--;
    }
    else{
        if(event.entity.getMainHandItem() !== 'minecraft:air') event.entity.block.popItem(Item.of('kubejs:wordcard', 1, {Word:"grant"}))
        else event.entity.block.popItem(Item.of('kubejs:wordcard', 1, {Word:"damage"}))
        if(!event.source.player.isCreative())event.player.offHandItem.damageValue--;
    }
})

BlockEvents.rightClicked(event=>{
    if(event.player.offHandItem.id !== 'kubejs:writable_wordcard' || event.player.offHandItem.damageValue === 0)return;
    if(event.block.hasTag('minecraft:beds') && Math.random() < 0.000001){
        event.block.popItem(Item.of("kubejs:wordcard", 1, {Word:"self"}));
    }
})
ItemEvents.rightClicked(event=>{
    if(event.player.offHandItem.id !== 'kubejs:writable_wordcard' || event.player.offHandItem.damageValue === 0)return;
    console.log(itemList[event.item.id])
    if(event.item.hasTag('forge:dyes')){
        event.player.give(Item.of("kubejs:wordcard", 1, {Word:'tint'}))
        event.item.shrink(1);
        if(!event.player.isCreative())event.player.offHandItem.damageValue--
    }
    if(!itemList[event.item.id])return;
    if(event.item.id === 'quark:bottled_cloud' && event.player.y <=255)return;
    event.player.give(Item.of("kubejs:wordcard", 1, {Word:itemList[event.item.id]}))
    event.item.shrink(1);
    if(!event.player.isCreative())event.player.offHandItem.damageValue--;
})