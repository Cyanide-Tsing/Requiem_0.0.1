/**@param {Array} list  */
function randomizingOutput(list){
    return list[Math.floor(list.length*Math.random())]
}

const legalBurningResults = {
    'interpret': function (player) {
        if(!player.persistentData?.unlockedWordUI){
            player.persistentData.unlockedWordUI = true;
            player.tell('UI OPEN')
        }
        else{
            let target = player.rayTrace(64, false)
            const returnVars = {
                'a':target.block?.id,
                'b':target.block?.pos,
                'c':target.entity?.type,
                'd':target.entity?.pos,
                'e':player.pos
            }
            let temp = randomizingOutput(['a', 'b', 'c', 'd', 'e'])
            if(returnVars[temp])player.tell(returnVars[temp])
            else player.tell(Text.translate("kubejs.casting.emptyReturn"))
        }
    },
    'wwwwww': function (player) {
        if(player.persistentData?.unlockedWordUI){
            player.persistentData.unlockedWordUI = false;
            player.tell('UI CLOSE')
        }
        else player.tell('UI ALREADY CLOSE')
    },
    'erupt': function (player) {}
}

ItemEvents.rightClicked('kubejs:wordcard',event=>{
    if(!event.player.isCrouching())return;
    let item = event.item
    if(event.player.offHandItem.id === 'kubejs:dictionary'){
        let word = item.nbt?.Word
        if(!event.player.offHandItem.nbt.Words.contains(NBT.stringTag(word))){
            if(!event.player.isCreative()){
                event.item.shrink(1);
                event.player.give('minecraft:paper')
            }
            event.player.offHandItem.nbt.Words.push(word);
        }
    }
})

ItemEvents.rightClicked('kubejs:writable_wordcard',event=>{
    let item = event.item
    if(event.player.offHandItem.id === 'kubejs:dictionary' && item.damageValue > 0){
        let word = item.nbt?.display.Name.split(':')[1].split('}')[0].split("\"")[1].split("\"")[0]
        console.log(word)
        if(event.player.offHandItem.nbt.Words.contains(NBT.stringTag(word))){
            if(!event.player.isCreative()){
                event.item.damageValue-=1;
            }
            event.player.give(Item.of('kubejs:wordcard', 1, {Word: word}))
        }
    }
})

//Burning card
NetworkEvents.dataReceived("global.burnKey.consumeClick", (event) => {
    if(event.player.mainHandItem.nbt.Word){
        let word = event.player.mainHandItem.nbt.Word;
        if(legalBurningResults[word]){
            legalBurningResults[word](event.player)
            event.player.tell('successfully burnt ' + word)
        } 
    }
});

//UI Part
let prevKey = false

PlayerEvents.loggedIn(event => {
    prevKey = false
    if(event.player.persistentData.unlockedWordUI === undefined){
        event.player.persistentData.unlockedWordUI = false;
    }
})

NetworkEvents.dataReceived("global.prevKey.consumeClick", (event) => {
    prevKey = !prevKey
    event.player.tell(prevKey)
});

PlayerEvents.tick(event => {
    let player = event.player
    if(player.age%5 !== 0)return;
    if(!player.persistentData?.unlockedWordUI){
        player.paint({notingUI: {remove: true}})
        player.paint({wordDisplay: {remove: true}})
        player.paint({bg: {remove: true}})
        return;
    }
    if(prevKey){
        if(player.mainHandItem.id !== 'kubejs:wordcard'){
            player.paint({notingUI: {remove: true}})
            player.paint({wordDisplay: {remove: true}})
            player.paint({bg: {remove: true}})
        }
        else{
            let displayedText = player.mainHandItem.nbt.Word;
                let containerWidth = 5*Math.max(displayedText.length, 4)+25
                player.paint({
                    notingUI: {
                        type: 'text',
                        text: '写有：',
                        x: -10, y: 60,
                        color: '#FFFFFF',
                        scale: 1.0,
                        shadow: true,
                        z: 1,
                        alignX:'right'
                    },
                    wordDisplay: {
                        type: 'text',
                        text: displayedText,
                        x: -10, y: 70,
                        color: '#00b7ff',
                        scale: 1.0,
                        shadow: true,
                        z: 1,
                        alignX:'right'
                    }
                });

                player.paint({
                    bg: {
                        type: 'rectangle',
                        x: -1, y: 55,
                        w: containerWidth, h: 30,
                        color: '#3dffffff', 
                        z: 0,
                        visible: true,
                        draw: 'ingame',
                        alignX:'right'
                    }
            });
        }
    }
    else{
        player.paint({notingUI: {remove: true}})
        player.paint({wordDisplay: {remove: true}})
        player.paint({bg: {remove: true}})
    }
})