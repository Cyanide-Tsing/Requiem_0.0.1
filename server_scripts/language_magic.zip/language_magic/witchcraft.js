const velocity = 5;
const MINIMUM = 1e-6

const presetObject = {
    "glacier":"twilightforest:ice_arrow",
    "fabrication":"minecraft:arrow",
    "pyre":"minecraft:fireball",
    "fire":"irons_spellbooks:fireball",
    "hot":"minecraft:small_fireball",
    "aqua":"alexscaves:water_bolt",
    "fulmen":"irons_spellbooks:ball_lightning",
    "void":"irons_spellbooks:magic_missile",
    "sanguine":"irons_spellbooks:blood_needle",
    "wither":"irons_spellbooks:wither_skull",
    "terra":"gtbcs_geomancy:dripstone_bolt",
}

const presetEntities = []

const presetObjectNBT = {
    "twilightforest:ice_arrow":{ pickup: 0, damage: 1.2, PierceLevel: 8},
    "minecraft:arrow":{ pickup: 0, damage: 1.4, PierceLevel: 8},
    "minecraft:fireball":{ExplosionPower:2, acceleration_power:0.15},
    "minecraft:small_fireball":{acceleration_power:0.15},
    "alexscaves:water_bolt":{Bubbling:0},
    "irons_spellbooks:ball_lightning":{Damage:6},
    "irons_spellbooks:magic_missile":{Damage:6},
    "irons_spellbooks:fireball":{Damage:6},
    "irons_spellbooks:blood_needle":{Damage:8},
    "minecraft:wither_skull":{Damage:8},
    "gtbcs_geomancy:dripstone_bolt":{Damage:6}
}

const presetObjectVelocity = {
    "twilightforest:ice_arrow":3,
    "minecraft:arrow":3,
    "minecraft:fireball":5,
    "minecraft:wither_skull":1.5,
    "minecraft:small_fireball":5,
    "alexscaves:water_bolt":1.5,
    "irons_spellbooks:ball_lightning":1.5
}

const presetNum = {
    "thrice":3
}

const legalGrant = ['self', 'crosshair', 'block', 'target']

const legalObjects = ["glacier", "fabrication", "pyre", "fire", "hot", "aqua", "fulmen", "void", "sanguine", "wither", "terra", "erupt", "lightning"]

const grantCompulsory = ["interpret", "dessociate", "associate", "ignite"]

const presetStaticObject = ["erupt", "lightning", "cloud"]

const weatherWord = ["water"]

const cannotDestroy = [
    "minecraft:bedrock",
    "minecraft:barrier",
    "minecraft:command_block",
    "minecraft:air",
    "minecraft:structure_block",
    "minecraft:jigsaw",
    "minecraft:nether_portal",
    "minecraft:end_portal_frame",
    "cataclysm:dungeon_block"
]

const faceMapping = {
    "up":[0, 1, 0],
    "down":[0, -1, 0],
    "north":[0, 0, -1],
    "south":[0, 0, 1],
    "east":[1, 0, 0],
    "west":[-1, 0, 0]
    //"noFace":[0, 0, 0]
}

function getLocalMaximum(Loops){
    let localMaximum = []; let tempLoopIndex=0;
    if(Loops.length<=1) return Loops;
    while(tempLoopIndex<Loops.length-1){
        if(Loops[tempLoopIndex].counter>Loops[tempLoopIndex+1].counter)localMaximum.push(Loops[tempLoopIndex]);
        tempLoopIndex++;
    }
    if(Loops[Loops.length-1].counter >= Loops[Loops.length-2].counter)localMaximum.push(Loops[Loops.length-1])
    return localMaximum;
}

function getSuperLoop(Loops, loop) {
    if(loop.counter === 0) return -1;
    for (let i = 0; i < Loops.length; i++) {
        if (Loops[i].counter === loop.counter - 1 && Loops[i].index < loop.index && Loops[i].end > loop.end) {
            return i;
        }
    }
    return -1;
}

function visionCalc(player){
    return {
        x:player.getViewVector(1.0).x()/Math.sqrt(player.getViewVector(1.0).x() * player.getViewVector(1.0).x() +
                                                      player.getViewVector(1.0).y() * player.getViewVector(1.0).y() +
                                                      player.getViewVector(1.0).z() * player.getViewVector(1.0).z()),
        y:player.getViewVector(1.0).y()/Math.sqrt(player.getViewVector(1.0).x() * player.getViewVector(1.0).x() +
                                                      player.getViewVector(1.0).y() * player.getViewVector(1.0).y() +
                                                      player.getViewVector(1.0).z() * player.getViewVector(1.0).z()),
        z:player.getViewVector(1.0).z()/Math.sqrt(player.getViewVector(1.0).x() * player.getViewVector(1.0).x() +
                                                      player.getViewVector(1.0).y() * player.getViewVector(1.0).y() +
                                                      player.getViewVector(1.0).z() * player.getViewVector(1.0).z())
    }
}

function granted(parsedSpell, index, player){
    let listOfVar = []
    let i = index+1
    let varSet = [];
    let target
    while(legalGrant.includes(parsedSpell[i]) && i<index+6){listOfVar.push(parsedSpell[i]);i++}
    if(listOfVar[0] === 'self'){
        if(listOfVar[1] === 'crosshair'){
            target = player.rayTrace(64, false)
            if(listOfVar[2] === 'block'){
                if(target && target.block){
                    varSet.push({Type:'block', ID:target.block.id,Pos:{x:target.block.x, y:target.block.y, z:target.block.z}, Data:target.block, Face:RFM(faceCalc(target.hit, target.block))});
                }
                //let j = 0;
                //while(j<512){
                    //if(lookingAtBlock(visionCalc(player), {x:player.x, y:player.y+1.6, z:player.z}, player.level, j/8).id !== 'minecraft:air')
                        //{   let block = lookingAtBlock(visionCalc(player), {x:player.x, y:player.y+1.6, z:player.z}, player.level, j/8)
                            //varSet.push({ID:block.id,Pos:{x:block.x, y:block.y, z:block.z}}); break;}
                    //j++;
                //}
            }
            else if(listOfVar[2] === 'target'){
                if(target && target.entity)varSet.push({Type:'entity', ID:target.entity.type, Pos:{x:target.entity.x, y:target.entity.y, z:target.entity.z}, Data:target.entity});
            }
            else varSet.push({Type:'vector', Pos:{x:player.x, y:player.y+1.6, z:player.z}, 
                                          nVis:visionCalc(player)})
        }
        else if(listOfVar[1] === 'block'){
            varSet.push({Type:'position', Pos:{x:player.block.x, y:player.block.y, z:player.block.z}})
        }
    }
    //player.tell(varSet)
    return varSet;
}

function lookingAtBlock(nVis, Pos, level, n){
    return level.getBlock(Math.floor(Pos.x+nVis.x*n), Math.floor(Pos.y+nVis.y*n), Math.floor(Pos.z+nVis.z*n))
}

function getDecimals(n){
    return n-Math.floor(n)
}

function RFM(resPos){
    for(let [key, vec] of Object.entries(faceMapping)) if(vec[0] === resPos[0] && vec[1] === resPos[1] && vec[2] === resPos[2])return key;
    return 'up';
}

function faceCalc(hitPos, blockPos){
    let dPos = [hitPos.x()-blockPos.x, hitPos.y()-blockPos.y, hitPos.z()-blockPos.z];
    let i;
    for(i=0; i<3; i++)if(getDecimals(dPos[i])<MINIMUM)break;
    let resPos = [0, 0, 0]
    resPos[i] = 2*Math.round(dPos[i])-1
    return resPos
}

ItemEvents.rightClicked('kubejs:wand',event=>{
    if(event.player.offHandItem.id !== 'kubejs:scratch_scroll' && event.player.offHandItem.id !== 'kubejs:makeshift_notebook')return;
    if(event.player.getCooldowns().isOnCooldown(event.player.offHandItem)){
        event.player.tell(Text.translate('kubejs.casting.machinegun'))
        event.player.attack(event.level.damageSources().magic(), 3);
        return;
    }
    //for(let prop in event.player.getCooldowns())console.log(prop)
    console.log('Start casting!')
    var operation = []
    //event.player.tell(event.player)
    let scroll = event.player.offHandItem;
    if((scroll.nbt?.Words && scroll.nbt?.Words.length === 0) || (scroll.nbt?.CurrentContent && scroll.nbt?.CurrentContent.length === 0)){//WIP
        event.player.tell(Text.translate('kubejs.casting.none'));
        return;
    }
    let spell = []
    if(event.player.offHandItem.id === 'kubejs:scratch_scroll') spell = scroll.nbt.Words;
    else if(event.player.offHandItem.id === 'kubejs:makeshift_notebook') spell = scroll.nbt.CurrentContent;
    let index = 0;
    let nVis = visionCalc(event.player)
    var projectile;
    var Projectiles = []
    var StatObject = []
    var BlockInteractions = []
    var EntityQueue = []
    var ProjectilesStep = []
    var Loops = []
    var loopCounter = 0
    let parsedSpell = []
    const Server = event.player.server
    const Player = event.player
    for(index = 0; index < spell.length; index++){
        if(spell[index] === "loop"){
            //Player.tell('LOOP')
            loopCounter++
            let repeatNum = 2
            if(presetNum[spell[index+1]]){repeatNum = presetNum[spell[index+1]];index++}
            let pos = Loops.length;
            Loops.push({position: pos, index:index, end:-1 ,counter:loopCounter-1, repeatNum:repeatNum, Operations:[]})
        }
        else if(spell[index] === "end"){
            //Player.tell('END')
            let i = Loops.length-1;
            if(Loops[Loops.length-1].end === -1){
                Loops[Loops.length-1].end = index-1
            }
            else {
                while(i>=0){
                    if(Loops[i].end === -1){Loops[i].end = index-1;break;}
                    i--
                }
            }
            loopCounter--;
        }
        else if(loopCounter !== 0){
            let pos;
            for(pos = Loops.length-1; pos>=0; pos--){if(Loops[pos].end === -1 && Loops[pos].index < index) break;}
            Loops[pos].Operations.push(spell[index])
        }
    }
    //parsing
    //按counter降序排序，从最深嵌套开始展开
    Loops.sort((a, b) => b.counter - a.counter);

    for (let i = 0; i < Loops.length; i++) {
        let loop = Loops[i];
        if (loop.counter === 0) continue;

        let parentIndex = getSuperLoop(Loops, loop);
        if (parentIndex === -1) {
            loop.counter = 0;
            continue;
        }
        let parent = Loops[parentIndex];
        let expandedOps = [];
        for (let r = 0; r < loop.repeatNum; r++) {
            loop.Operations.forEach(op=>{
                expandedOps.push(op);
            })
        }
        expandedOps.forEach(op=>{parent.Operations.push(op);})
        Loops.splice(i, 1);
        i--;
    }
    //Player.tell(Loops)
    //此时loops应该只有0级循环，合并至parsedSpell
    Loops.sort((a, b) => a.index - b.index);
    let varSet = []

    let loopIdx = 0;
    for (let i = 0; i < spell.length; i++) {
        if (loopIdx < Loops.length && Loops[loopIdx].index === i) {
            let loop = Loops[loopIdx];
            for (let r = 0; r < loop.repeatNum; r++) {
                loop.Operations.forEach(op => {
                    parsedSpell.push(op);
                });
            }
            i = loop.end;
            loopIdx++;
        } else {
            if (spell[i] !== "loop" && spell[i] !== "end") {
                parsedSpell.push(spell[i]);
            }
        }
    }

    for(index = 0; index < parsedSpell.length; index++){
        if(parsedSpell[index] === "new"){
            if(!legalObjects.includes(parsedSpell[index+1]) || index+1 === parsedSpell.length){
                operation.push((next, args) => {
                    event.player.tell(Text.translate('kubejs.casting.invalidObject'));
                    return;
                });
            }
            //if(parsedSpell[index+2] === 'grant'){
                //varSet = granted(parsedSpell, index, Player)
                //Player.tell(listOfVar)
                //Player.tell(visionCalc(Player))
                //Player.tell(varSet)
            //}
            if(parsedSpell[index+2] !== "link"){
                //如果是弹射物
                if(presetObject[parsedSpell[index+1]]){
                    //Player.tell('new')
                    Projectiles.push({Name:presetObject[parsedSpell[index+1]],index:index})
                }
                else if(presetStaticObject.includes[parsedSpell[index+1]]){
                    StatObject.push({Name:parsedSpell[index+1],index:index})
                }
            }
        }
        else if(parsedSpell[index] === "grant"){
            //Player.tell('grant')
            varSet.push(granted(parsedSpell, index, Player))
        }
        else if(parsedSpell[index] === "evoke"){
            //Player.tell('evoke')
            operation.push((next,args) => {
                if(projectile){
                    projectile.spawn()
                }
                next(args++);
            })
        }
        else if(parsedSpell[index] === "recoil"){
            operation.push((next,args) => {
                Server.scheduleInTicks(10, ()=>{
                    projectile = null;
                    next(args++)});
            })
        }
        else if(presetObject[parsedSpell[index]]){
            //Player.tell(projectileData.nVis)
            //Player.tell('projectile')
            operation.push((next, args) => {
                //Player.tell('NEW OBJ')
                let projectileID = Projectiles.shift().Name
                let projectileData = varSet.shift()
                //Player.tell(projectileData)
                if(projectileData){
                    projectileData.forEach(data =>{
                        let vis, pos;
                        //console.log(data)
                        if(data.nVis)vis = data.nVis;
                        else vis = visionCalc(Player)//nVis
                        if(data.Pos)pos = data.Pos
                        else pos = {x:Player.x, y:Player.y+1.6, z:Player.z}
                        projectile = Player.level.createEntity(projectileID);
                        let speed = velocity;
                        if(presetObjectVelocity[projectileID]) speed = presetObjectVelocity[projectileID]
                        projectile.setMotion(vis.x*speed+(Math.random()-0.5)*speed/10, vis.y*speed+(Math.random()-0.5)*speed/10, vis.z*speed+(Math.random()-0.5)*speed/10);
                        projectile.setPosition(pos.x, pos.y, pos.z);
                        projectile.setOwner(Player);
                        projectile.mergeNbt(presetObjectNBT[projectileID])
                    })
                }
                else{
                    let vis = visionCalc(Player)//nVis
                    let pos = {x:Player.x, y:Player.y+1.6, z:Player.z}
                    projectile = Player.level.createEntity(projectileID);
                    let speed = velocity;
                    if(presetObjectVelocity[projectileID]) speed = presetObjectVelocity[projectileID]
                    projectile.setMotion(vis.x*speed+(Math.random()-0.5)*speed/10, vis.y*speed+(Math.random()-0.5)*speed/10, vis.z*speed+(Math.random()-0.5)*speed/10);
                    projectile.setPosition(pos.x, pos.y, pos.z);
                    projectile.setOwner(Player);
                    projectile.mergeNbt(presetObjectNBT[projectileID])
                }
                next(args++);
            })
        }
        else if(grantCompulsory.includes(parsedSpell[index])){
            let vars = varSet.shift()
            if(vars){
                switch (parsedSpell[index]) {
                    case 'interpret':
                        if(vars.length>0){
                            event.player.tell(Text.translate('kubejs.casting.wisp'));
                            vars.forEach(value=>{
                                if(!value.Data) event.player.tell(value);
                                else {
                                    event.player.tell('ID: ' + value.ID + ', ' + 'Pos: {' + value.Pos.x + ', ' + value.Pos.y + ', ' +value.Pos.z + '}');
                                    if(value?.Face)event.player.tell('Face:' + value.Face)
                                }
                            })
                        }
                        else Player.tell(Text.translate('kubejs.casting.emptyReturn'))
                        break;
                    case 'dessociate':
                        if(vars.length>0){
                            vars.forEach(value=>{
                                let pos = [Math.floor(value.Pos.x), Math.floor(value.Pos.y), Math.floor(value.Pos.z)]
                                if(!cannotDestroy.includes(event.player.level.getBlock(pos).id)){
                                    let dropXP = false;
                                    if(event.player.level.getBlock(pos).id === 'kubejs:arcane_crystal' && !event.player.isCreative()){
                                        dropXP = true;
                                    }
                                    BlockInteractions.push({Pos:pos, dropXP:dropXP})
                                    operation.push((next,args)=>{
                                        let blockDestroy = BlockInteractions.shift()
                                        if(blockDestroy.dropXP){
                                            let xp = Player.level.createEntity('minecraft:experience_orb')
                                            xp.mergeNbt({Count:1, Value:1})
                                            xp.setPosition(blockDestroy.Pos[0]+0.5, blockDestroy.Pos[1], blockDestroy.Pos[2]+0.5);
                                            xp.spawn()
                                        }
                                        Player.level.destroyBlock(blockDestroy.Pos, true)
                                        next(args++);
                                    })
                                }
                                else Player.tell(Text.translate('kubejs.casting.forbidden'))
                            })
                        }
                        else Player.tell(Text.translate('kubejs.casting.withoutParam'))
                        break;
                    case 'associate':
                        if(vars.length>0){
                            vars.forEach(value=>{
                                let pos = [Math.floor(value.Pos.x), Math.floor(value.Pos.y), Math.floor(value.Pos.z)]
                                //Player.tell(value)
                                for(let i=0; i<3; i++){
                                    pos[i]+=faceMapping[value.Face][i]
                                }
                                BlockInteractions.push({Pos:pos, id:'kubejs:arcane_crystal'})
                                operation.push((next,args)=>{
                                    let blockBuild = BlockInteractions.shift()
                                    Player.level.getBlock(blockBuild.Pos).set(blockBuild.id)
                                    next(args++);
                                })
                            })
                        }
                        else Player.tell(Text.translate('kubejs.casting.withoutParam'))
                        break;
                    case 'ignite':
                        if(vars.length>0){
                            vars.forEach(value=>{
                                let pos = [Math.floor(value.Pos.x), Math.floor(value.Pos.y), Math.floor(value.Pos.z)]
                                if(value?.Face){
                                    for(let i=0; i<3; i++){
                                        pos[i]+=faceMapping[value.Face][i]
                                    }
                                }
                                //Player.tell(value.Face)
                                if(value.Type === 'block' && Player.level.getBlock(pos).id === "minecraft:air"){
                                    BlockInteractions.push({Pos:pos, id:'minecraft:fire'})
                                    operation.push((next,args)=>{
                                        let blockBuild = BlockInteractions.shift()
                                        if(Player.level.getBlock(blockBuild.Pos).down.properties?.lit === false){
                                            let block = Player.level.getBlock(blockBuild.Pos).down
                                            let tempProps = []
                                            for(let prop in block.properties){
                                                if(prop === 'lit') tempProps.push('lit=true')
                                                else tempProps.push(prop+'='+block.properties[prop])
                                            }
                                            let blockEntityData = block.entityData
                                            event.server.runCommandSilent(`setblock ${block.pos.x} ${block.pos.y} ${block.pos.z} ${block.id}[${tempProps}]`)
                                            block.mergeEntityData(blockEntityData)
                                        }
                                        else Player.level.getBlock(blockBuild.Pos).set(blockBuild.id)
                                        next(args++);
                                    })
                                }
                                else if(value.Type === 'entity'){
                                    if(value.Data){
                                        EntityQueue.push(value.Data)
                                        operation.push((next,args)=>{
                                            let entity = EntityQueue.shift();
                                            entity.attack(event.level.damageSources().inFire(), 5);
                                            entity.setSecondsOnFire(5);
                                            next(args++)
                                        })
                                    }
                                }
                            })
                        }
                        break;
                    default:
                        Player.tell(Text.translate('kubejs.casting.withoutParam'))
                        break;
                }
            }
            else Player.tell(Text.translate('kubejs.casting.withoutParam'))
        }
        else if(parsedSpell[index] === "cloud" && ( index<1 || parsedSpell[index-1] !== 'new')){
            switch (parsedSpell[index+1]) {
                case 'water':
                    operation.push((next,args)=>{
                        Player.level.setWeatherParameters(0, 20000, true, false);
                        next(args++)
                    })
                    break;
                case 'lightning':
                    operation.push((next,args)=>{
                        Player.level.setWeatherParameters(0, 20000, true, true);
                        next(args++)
                    })
                    break;
                case 'solar'://how to get it?
                    operation.push((next,args)=>{
                        Player.level.setWeatherParameters(0, 20000, false, false);
                        next(args++)
                    })
                    break;
                default:
                    operation.push((next,args)=>{
                        Player.block.spawnLightning()
                        Player.attack(event.level.damageSources().lightningBolt(), 24);
                        next(args++)
                    })
                    break;
            }
        }
        else if(( index>=1 && parsedSpell[index-1] === 'new') && presetStaticObject.includes(parsedSpell[index])){
            EntityQueue.shift()
            if(varSet.length >= 0){
                switch (parsedSpell[index]){
                    case 'erupt':
                        operation.push((next,args)=>{
                            let vars = varSet.shift().shift()
                            Player.level.createExplosion(vars.Pos.x, vars.Pos.y, vars.Pos.z).strength(2).explosionMode('block').explode()
                            next(args++)
                        })
                        break;
                    case 'lightning':
                        operation.push((next, args)=>{
                            let vars = varSet.shift().shift()
                            Player.level.getBlock(vars.Pos.x, vars.Pos.y, vars.Pos.z).spawnLightning()
                            if(vars.Type === 'entity'){
                                vars.Data.attack(Player.level.damageSources().lightningBolt(), 10)
                            }
                            next(args++)
                        })
                        break;
                    default:
                        Player.tell(Text.translate('kubejs.casting.withoutParam'))
                        break;
                }
            } 
        }
        else {
            operation.push((next,args)=>{
                next(args++)
            })
        }
    }
    if(loopCounter !== 0){event.player.tell(Text.translate('kubejs.casting.brokenLoops'));return;}
    
    let tempLoopIndex=0;
    while(tempLoopIndex<Loops.length){
        if(Loops[tempLoopIndex].counter>0)event.player.tell(Text.translate('kubejs.casting.cascadingLoopWarn'));
        tempLoopIndex++;
    }

    function runSpell() {
        let i = 0;
        function step(args) {
            if (i >= operation.length) {
                return;
            }
            const op = operation[i++];
            //Player.tell(Operations[i])
            op(step, args);
        }
        step(0);
    }
    runSpell();
    if(event.player.offHandItem.id === 'kubejs:scratch_scroll') event.player.addItemCooldown(event.player.offHandItem, event.player.offHandItem.nbt?.Words.length*5);
    else if(event.player.offHandItem.id === 'kubejs:makeshift_notebook') event.player.addItemCooldown(event.player.offHandItem, event.player.offHandItem.nbt?.CurrentContent.length*4);
})

ItemEvents.rightClicked('kubejs:makeshift_notebook', event => {
    if(!event.player.isCrouching() && event.item.nbt.Content.length > 0){
        let temp = event.item.nbt.key
        temp = (temp+1)%event.item.nbt.Content.length
        event.item.nbt.merge({key:temp})
        event.item.nbt.merge({CurrentContent:event.item.nbt.Content[temp]})
        event.player.tell(Text.translate('kubejs.casting.nextpage'))
        event.player.tell(event.item.nbt.Names[temp])
    }
    else if(event.player.isCrouching() && event.item.nbt.Content.length > 0){
        let temp = event.item.nbt.key
        temp = (temp+event.item.nbt.Content.length-1)%event.item.nbt.Content.length
        event.item.nbt.merge({key:temp})
        event.item.nbt.merge({CurrentContent:event.item.nbt.Content[temp]})
        event.player.tell(Text.translate('kubejs.casting.nextpage'))
        event.player.tell(event.item.nbt.Names[temp])
    }
})

//ItemEvents.rightClicked('minecraft:iron_ingot', event => {})
/*
    let target = event.player.rayTrace(64, false)
    let pos = target.block.pos
    let tempProps = []
    for(let prop in target.block.properties){
        if(prop === 'lit') tempProps.push('lit=true')
        else tempProps.push(prop+'='+target.block.properties[prop])
    }
    let blockEntityData = target.block.entityData
    event.server.runCommandSilent(`setblock ${pos.x} ${pos.y} ${pos.z} ${target.block.id}[${tempProps}]`)
    target.block.mergeEntityData(blockEntityData)

    //event.player.level.setBlock(pos, state, 1)
    //event.player.tell(114514)
    //event.player.tell(target.block.blockState.getBlock().getStateDefinition().getProperty("lit"))
    //event.player.tell(target.block.blockState.properties)
    //for(let prop in target.block){
    //    console.log(prop)
    //}
    //target.block.setBlockState(target.block.properties.lit)
    //if(target.block.properties && target.block.properties.lit === false){
    //}
    //let state = target.block.blockState
    //console.log(target.block.properties)
    //console.log(target.block.entityData)
    //event.player.tell(`setblock ${pos.x} ${pos.y} ${pos.z} ${target.block.id}[${tempProps}]`)
*/

//BlockEvents.broken('kubejs:arcane_crystal', event => {
//    let xp = event.block.level.createEntity('minecraft:experience_orb')
//    xp.mergeNbt({Count:1, Value:1})
//    xp.setPosition(event.block.pos);
//    xp.spawn()
//})

//event.player.level.setWeatherParameters(0, 20000, true, false);
//let target = event.player.rayTrace(64, false)
//target.block.spawnLightning()
//event.player.block.spawnLightning()