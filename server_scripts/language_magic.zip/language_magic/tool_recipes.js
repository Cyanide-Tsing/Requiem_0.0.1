ServerEvents.recipes(event=>{
    //清空
    event.shapeless(Item.of('kubejs:dictionary', 1, {Words:[]}), [Item.of('kubejs:dictionary',1), "supplementaries:soap"]).id("requiem:crafting/dictionary_clean")
    event.shapeless(Item.of('kubejs:scratch_scroll', 1, {Words:[]}), [Item.of('kubejs:scratch_scroll',1), "supplementaries:soap"]).id("requiem:crafting/scroll_clean")
    event.shapeless(Item.of('kubejs:makeshift_notebook', 1, {Content:[], CurrentContent:[], Names:[], key:0}), [Item.of('kubejs:makeshift_notebook',1), "supplementaries:soap"]).id("requiem:crafting/note_clean")

    //空白词卡
    event.shapeless(Item.of('kubejs:writable_wordcard', 1, {Damage: 6}), ['minecraft:feather','minecraft:ink_sac','minecraft:gold_nugget','6x minecraft:paper']).id('requiem:crafting/writable_wordcard')
    event.shapeless(Item.of('kubejs:writable_wordcard', 1, {Damage: 6}), ['minecraft:feather','supplementaries:antique_ink','minecraft:gold_nugget','6x minecraft:paper']).replaceIngredient("supplementaries:antique_ink","minecraft:glass_bottle").id('requiem:crafting/writable_wordcard_alt')
    event.shapeless(Item.of('kubejs:writable_wordcard', 1, {Damage: 6}), ['kubejs:writable_wordcard', '6x minecraft:paper','minecraft:ink_sac']).id('requiem:crafting/writable_wordcard_renewal')
    event.shapeless(Item.of('kubejs:writable_wordcard', 1, {Damage: 6}), ['kubejs:writable_wordcard', '6x minecraft:paper','supplementaries:antique_ink']).replaceIngredient("supplementaries:antique_ink","minecraft:glass_bottle").id('requiem:crafting/writable_wordcard_renewal_alt')

    //词典
    event.shaped(Item.of('kubejs:dictionary', 1, {Words:[]}), ['ABC','DE ','   '], {A:'#forge:feathers', B:'minecraft:book', C:'minecraft:blue_wool', D: 'minecraft:ink_sac', E: 'minecraft:red_wool'}).id("requiem:crafting/dictionary")
    event.shaped(Item.of('kubejs:dictionary', 1, {Words:[]}), ['ABC','DE ','   '], {A:'#forge:feathers', B:'minecraft:book', C:'minecraft:blue_wool', D: 'supplementaries:antique_ink', E: 'minecraft:red_wool'}).id("requiem:crafting/dictionary_alt")

    //卷轴
    event.shaped(Item.of('kubejs:scratch_scroll', 1, {Words:[]}), ['AAA', 'ABA', 'AAA'], {A:'minecraft:paper', B:'minecraft:stick'}).id("requiem:crafting/scratch_scroll")

    //法术书
    event.shaped(Item.of('kubejs:makeshift_notebook', 1, {Content:[], CurrentContent:[], Names:[], key:0}), [' A ', 'BCD', ' E '], {A:'minecraft:green_dye', B:'minecraft:red_wool', C:'minecraft:writable_book', D:'minecraft:compass', E:'kubejs:scratch_scroll'}).id("requiem:crafting/makeshift_notebook")

    //墨水
    event.recipes.create.filling('supplementaries:antique_ink',[Fluid.of('create_enchantment_industry:ink', 250), 'minecraft:glass_bottle']).id('requiem:filling/antique_ink')
    event.recipes.create.emptying([Fluid.of('create_enchantment_industry:ink', 250), 'minecraft:glass_bottle'], 'supplementaries:antique_ink').id('requiem:emptying/ink')

    //法杖
    event.shapeless(Item.of('kubejs:wand', 1), ['minecraft:stick','minecraft:lapis_lazuli',Item.of('kubejs:wordcard', 1, {Word:"termination"}).strongNBT()]).id('requiem:crafting/wand')

    //抄写台
    event.shaped(Item.of('kubejs:scribble_table', 1, {Content:[], CurrentContent:[], Names:[], key:0}), ['ABA', 'ECD', 'FFF'], {A:'minecraft:spruce_wood', B:'minecraft:stripped_spruce_wood', C:'#forge:bookshelves', D:'supplementaries:antique_ink', E:'#forge:feathers', F:'minecraft:spruce_planks'}).id("requiem:crafting/scribble_table")
})